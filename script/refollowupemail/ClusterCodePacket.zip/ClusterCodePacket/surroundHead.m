%Surround Head

%Enter size of Matrix, and data point and function will return all
%neighboring points within the specified matrix that are significant
%including the original significant point

%Frequencies are neighbors if they are adjacent to each other

%Channels are neighbors if they are less than 4cm from
%each other.

%'dSet' - The Significance Matrix
%'freqP' - Frequency 
%'chan' - Channel
%'distance' - Sensor Distance Matrix

function[nSigHead,nHead] = surroundHead(dSet,freqP,chan,distance)

mx = size(dSet,1);
my = size(dSet,2);

%Find Neighboring Frequency Points
    fRange = 1; %Size of frequency range in either direction
    nR = -fRange:fRange;
    nfreqs = transpose(freqP+nR);  %Actual frequencies in range (freqP is center)

%Find Neighboring Channels
    nChan = find(distance(chan,:)<4);
    chanNo = size(nChan,2);

%Compile all neighbors
    nHead = [];

    for y = 1:chanNo
        tempChans = zeros(size(nfreqs));
        tempChans(:) = nChan(y);
        connect = [nfreqs,tempChans];
        nHead = cat(1,nHead,connect);
    end

    nSize = size(nHead,1);

%Delete points that go beyond dimensions of initial data set
for a = 1:nSize
    if ((nHead(a,1) > mx)|| (nHead(a,1)<1))
       nHead(a,:) = -1;
    elseif ((nHead(a,2) > my)|| (nHead(a,2)<1))
       nHead(a,:) = -1;
    end
end

Del = find(nHead(:,1)<0);
nHead(Del,:) = [];
nSize = size(nHead,1);

%Find Significant Surround Points (extension)
nSigData = zeros(nSize,1);
for a = 1:nSize
       nSigData(a) = dSet(nHead(a,1),nHead(a,2)); %To check whether surrounding points are significant
end

nSigHead = find(nSigData>0);
nSigHead = nHead(nSigHead,:);   %Gives significant surrounding points

    