%searchHead. Inner recursion loop of 'recursiveClustHeadN.m'. 

function[]=searchHead(f,c,count,distance,range)

global input1;
global visited;


fSize = size(input1,1);
cSize = size(input1,2);


%Return if out of bounds of matrix
if ((f<1)||(f>fSize)||(c<1)||(c>cSize))
    return;
end

%Return if point has been visited
if (visited(f,c) == 1)
    return;
else
   visited(f,c) = 1; %Mark as visited
end

%If end point of cluster is hit
if (input1(f,c) == 0)
    return;
else
    input1(f,c) = count;
end

%Recursion -----%Modified for updated channel/frequency neighbor detection

%Channel Neighbors
nChan = find(distance(c,:)<4);
chanNo = size(nChan,2);

%Recursion
%w/ Frequency Neighbors
 
for x = f-1:f+1
    for y = 1:chanNo
      searchHead(x,nChan(y),count,distance,range);
    end
end
 
%Additional code for creating frequency neigborhood range

%Checks forward range
for y = f+1:f+range
   if ((y>0) && (y<=fSize))
          if (input1(y,c) == 1)
                     for a = f:y-1
                              input1(a,c)= count;
                              visited(a,c) = 1;
                     end
	         searchHead(y,c, count,distance, range);
          end
    end
end
 

%Checks reverse range
for y = f-range: f-1
    if ((y>0) && (y<=fSize))
          if (input1(y,c) == 1)
                     for a = y+1:f
                              input1(a,c)= count;
                              visited(a,c) = 1;
                     end
	         searchHead(y,c, count,distance, range);
          end
    end
end
 
 
 
end

