%Recursive cluster code to find clusters of significance in a 2D matrix.
%The conditions of clustering have been modified to work with a 148 channel
%head plot. Sensor distance determines neighborhood in the y-axis and
%frequency distance determines neighborhood in the
%x-axis.

%There is now a provision to add a 'range' variable to frequency
%clustering. If a cluster is found within the 'range' distance of another
%cluster then both clusters are joined together (filling in the blank space). 

%RecursiveClustHeadN - Version 'N' operates as a function. There is now an
%option to provide clustering for either positive negative significance
%values. This can be controlled by entering either 'P' or 'N' for the 'sign'
%input in the function. 

%recursiveClustHeadN - Inputs(tval,distance,dof,sign)
%'tval' - tval matrix for a given subject
%'distance' - sensor distance matrix
%'dof' - degrees of freedom vector (for each channel)
%'sign' - Searches for positive or negative significant tvalues depending
%on whether the input is 'P' or 'N'. 

%'Input1' is the significance matrix that is clustered and modified
%throughout this m.file. 'Input1' is saved at various points in the
%process:
%Input0 - No clustering performed
%InputX - Basic clustering w/ singularity removal
%InputXC - Final cleaned cluster w/ removal of all clusters w/ less than
%five channels (with a renumbering after 'bad' clusters were deleted).

%--------------------------------------------------------------------------


function[inputXC,inputX,input0,csuSizeC,fsuSizeC,clustSize,clustPointsC,tvalSums] = recursiveClustHeadN(tval,distance,dof,sign)

global input1;
global visited;

set(0,'RecursionLimit',3000)
range = 0; %Frequency Neighbour Range -'4'-->'1Hz'
%----------------------------------

%Initial Variables
tThresh = -tinv(0.05,dof);
input1 = zeros(1001,148); %Matrix that will be "clustered"

visited = zeros(size(input1));%'visited' matrix to prevent unnecessary recursions
cSize = size(input1,2); %No. of channels
fSize = size(input1,1); %No. of frequencies



%Set t-values of channels with dof less than '2' to '0'
zeroChans = find(dof<3);
tval(:,zeroChans) = 0;


%Creation of significance matrix from t-value matrix

if sign == 'P'
    
    for x = 1:cSize
    tempInp = zeros(fSize,1);
    clustInd = find(tval(:,x) >= tThresh(x));
    tempInp(clustInd) = 1;
    input1(:,x) = tempInp;
    end
    
    
    
elseif sign == 'N'
    
    for x = 1:cSize
    tempInp = zeros(fSize,1);    
    clustInd = find(tval(:,x) <= -tThresh(x));
    tempInp(clustInd) = 1;
    input1(:,x) = tempInp;
    end

end    
   
count = 1; %Cluster Counter
input0 = input1; %Initial Input (as Input1 is modified during clustering)

%Outter Shell of Recursive Loop
for c= 1:cSize
    for f =1:fSize
        
        if (visited(f,c) == 0)
            
            if (input1(f,c) ==1)
                
                searchHead(f,c,count,distance,range); %Inner Shell of Recursive Loop
                singularity = 1;
                                                            
                
                neighbors = surroundHead(input1,f,c,distance); %Singularity Detection m.file
                if size(neighbors,1) > 1
                    singularity = 0;
                end
               
        
                if (singularity == 1); %If the cluster is a singularity then it will be deleted.
                    input1(f,c) = 0;
                else
                    count = count+1;
                end
                
                
            end
        
        end
        
    end
   
end

inputX = input1; %Clustered Output (w/o post-recursive modifications)

%--------------------------------------------------------------------------
%Post-Recursion Modification (Remove all clusters with less than 5
%channels)


numClust = max(max(input1)); %# of cluster before post-recursive modification
csuSize = []; %# of unique channels per cluster
fsuSize = []; %# of unique frequencies per cluster

    %Determine #unique channels and frequencies per cluster
    for x = 1:numClust
        [fs,cs] = find(input1==x);
        csu = unique(cs);
        fsu = unique(fs);
        csuSize(x) = size(csu,1);
        fsuSize(x) = size(fsu,1);
    end

    badClust = find(csuSize<5); %'bad' clusters (clusters w/less than 5 channels).
    badClustNo = size(badClust,2);%# or 'bad' clusters.

    shadowClust = 1:numClust; %cluster index for compression (renumbering after removal of bad clusters)
    shadowClust(badClust) = 0;

    %Blank Out Bad Clusters
    for i = 1:badClustNo
        destroy = find(input1==(badClust(i)));
        input1(destroy) = 0;  
    end


    %Recompress Input1 - Renew Cluster Numbering
    trueClustNo = numClust - badClustNo; %# of clusters left after 'bad' ones have been deleted

    for i = 1:trueClustNo
        
        clusterSearch = find(input1 == i);
        
        if size(clusterSearch,1) == 0;
            for z = i+1:numClust
                if shadowClust(z)>0
                    shadowClust(i) = i;
                    shadowClust(z) = 0;
                    break;
                end        
            end

        cReplace = find(input1 == z);    
        input1(cReplace) = i;    

        end

    end

    inputXC = input1; %Clustered Output (w/ post-recursive modifications)

%--------------------------------------------------------------------------
%Final Cluster Information
    
    %Determine # channels and frequencies per cluster in CLEANED DATASET
        csuSizeC = []; %# of unique channels per cleaned cluster
        fsuSizeC = []; %# of unique frequencies per cleaned cluster
        clustPointsC = cell(1,trueClustNo);

        for x = 1:trueClustNo
            [fsC,csC] = find(input1==x);
            csuC = unique(csC);
            fsuC = unique(fsC);
            cluC = zeros(size(fsC));
            cluC(:) = x;
            csuSizeC(x) = size(csuC,1);
            fsuSizeC(x) = size(fsuC,1);

            clustPointsC{x} = [fsC,csC,cluC]; %cell that contains all clusters and the data points associated w/ each cluster
        end


    %ClusterSize and t-value cluster sums
    clustSize = zeros(1,trueClustNo); %Size of each cluster
    tvalSums = zeros(1,trueClustNo); %t-value sum of each cluster

    for x = 1:trueClustNo
        clustSize(x) = size(clustPointsC{x},1); 

        tvalSum = 0; 
        for y = 1:size(clustPointsC{x},1);
        tvalAppend = tval(clustPointsC{x}(y,1),clustPointsC{x}(y,2));
        tvalSum = tvalSum + tvalAppend;
        end
        tvalSums(x) = tvalSum;

    end




end











