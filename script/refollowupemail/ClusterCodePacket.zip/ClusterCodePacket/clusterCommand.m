%clusterCommand

%Command center for cluster statistic code.
%Uses 'recursiveClustHeadN.m'
%--------------------------------------------------------------------------

fpath = fullfile(G.paths.root,'projects','experiment_mfiles','betabeat','ClusterCodePacket','');

load(fullfile(fpath,'sensor_distance.mat'))
load(fullfile(fpath,'powerSpectraData.mat'))

%Variable Initialization
subjects = 1:122;
subjects = 1
monte = 500; %Number of bootstrap trials
sign = 'P'; %Positive or negative tail test? 'P'/'N'
subSize = size(subjects,2);

%Variables stored for each subject: 
tvalSumsSub = cell(1,subSize); %(1) sum of t-values for each cluster
clustPointsCSub = cell(1,subSize); %(2) cluster cell(contains the data points associated with each cluster)
tvalMonteSub = zeros(subSize,monte);%(3) Bootstrap t-value distribution 
sigClusterSub = cell(1,subSize);%(4) clusters that passed the bootstrap significance
tvalSub = cell(1,subSize);%(5) t-value matrix 
clustSizeSub = cell(1,subSize);%(6) 2D size of clusters

for s = subjects;
    
    %m.file directory
    %cd('/Users/eugenejoseph/Desktop/Matlab Files/m-files')
    
    %Part1:Invoke t-value data set and find all clusters-------------------    
    smData = squeeze(spectra_smFull8(:,:,:,s));
    wmData = squeeze(spectra_wmFull8(:,:,:,s));

    trueSet = cat(3,smData,wmData);

    [h,p,ci,stats] = ttest(trueSet(:,:,1:8),trueSet(:,:,9:16),[],[],3);
    dof = stats.df;
    dof = nanmean(dof,1); %DOF for each channel        
    tval = stats.tstat; %t-value matrix
    
    tvalSub{s} = tval;

    [inputXC,inputX,input0,csuSizeC,fsuSizeC,clustSize,clustPointsC,tvalSums] = recursiveClustHeadN(tval,distance,dof,sign); %recursive clustering

    tvalSumsSub{s} = tvalSums;
    clustPointsCSub{s} = clustPointsC;
    clustSizeSub{s} = clustSize;


    %Part2:BootStrap Test--------------------------------------------------

    tvalMonte = zeros(1,monte); 
    clustMonte = zeros(1,monte);

    for x = 1:monte
      
      fprintf('bootstrap replication #%d of %d\n',x,monte)

    shuffled = trueSet(:,:,randperm(size(trueSet,3))); %Shuffle the 8 SM and WM trials

      [h,p,ci,stats] = ttest(shuffled(:,:,1:8),shuffled(:,:,9:16),[],[],3);
      dof = stats.df;
      tval = stats.tstat;  
      dof = nanmean(dof,1);        

    % 'F' stands for 'fake' at the end of all the variable names below
    [inputXCF,inputXF,input0F,csuSizeCF,fsuSizeCF,clustSizeF,clustPointsCF,tvalSumsF] = recursiveClustHeadN(tval,distance,dof,sign);
    
        if sign == 'P'
            [tvalMonte(x),clustMonte(x)] = max(tvalSumsF);
            shuffled = [];   
        elseif sign == 'N'
            [tvalMonte(x),clustMonte(x)] = min(tvalSumsF);    
            shuffled = [];   
        end
        
    end
    tvalMonteSub(s,:) = tvalMonte;

    %Part3:Bootstrap Evaluation--------------------------------------------
    
    if sign == 'P'
        sigPlate = (floor(0.95*monte));
        sigCluster = [];
        curve = sort(tvalMonte);
        
    elseif sign == 'N'
        sigPlate = (floor(0.95*monte));
        sigCluster = [];
        curve = sort(tvalMonte,2,'descend');
        
   
    end
    
    
    %Monte Carlo Visualization
    bootStrapPlot = figure;
    plot(curve);
    hold on
    stem(curve);
    hold on
    ylabel('Summed t-values');
    titleHead = sprintf('Subject %g -%s',s,sign);
    title(titleHead);
    line([1,monte],[curve(sigPlate),curve(sigPlate)],'Color','k')
    hold on
%}
    
    cc = 1;
    
    if sign == 'P'
        
        for b = 1:size(clustPointsC,2)
            stem(tvalSums(b),'r'); %Monte Carlo Visualization
            hold on

            if tvalSums(b) > curve(sigPlate)
               sigCluster{cc} = clustPointsC{b};
               cc = cc+1;
            end

        end
        
    elseif sign == 'N'
        
         for b = 1:size(clustPointsC,2)
            stem(tvalSums(b),'r'); %Monte Carlo Visualization
            hold on

            if tvalSums(b) < curve(sigPlate)
               sigCluster{cc} = clustPointsC{b};
               cc = cc+1;
            end

         end 
    end
        

    sigClusterSub{s} =sigCluster; %Stores significant clusters for each subject
    
    %Save Bootstrap Visualization Images
     fileName1 = sprintf('Subject %g BootStrap %s',s,sign);
     %cd('/Users/eugenejoseph/Desktop/Matlab Data Archive/Mar-19-12/Bootstrap Images')
     saveas(bootStrapPlot,fullfile(fpath,'Bootstrap Images',fileName1),'fig') 
     close(bootStrapPlot);
    
    
    %Part4:Significant Cluster Visualization-------------------------------
    if size(sigCluster,1)>0 %Check is any clusters are significant
    
        for x=1:size(sigCluster,2)
            
            clustVis = figure;
            subplot(1,2,1)
            
                chans = unique(sigCluster{x}(:,2));
                chanSize = size(chans,1);
                tCSums = zeros(1,chanSize); %t-value channel sum (over all frequencies for one channel)

                    for j = 1:chanSize

                        chanPoints = find(sigCluster{x}(:,2) == chans(j)); %no of frequencies points per channel
                        pointSizeC = size(chanPoints,1);
                        tSum = 0;

                        for i = 1:pointSizeC
                        tVal = tvalSub{s}(sigCluster{x}(chanPoints(i),1),sigCluster{x}(chanPoints(i),2));
                        tSum = tSum+tVal;
                        
                        end   
                        
                        tCSums(j) = tSum;
                    end

                hPSkel = zeros(1,148);
                hPSkel(chans) = (tCSums);
                plot_head(hPSkel);
                caxis([-20 20]);
                colormap jet
           
            subplot(1,2,2)

                freqs = unique(sigCluster{x}(:,1));
                freqSize = size(freqs,1);
                tFSums = zeros(1,freqSize);

                for j = 1:freqSize

                    freqPoints = find(sigCluster{x}(:,1) == freqs(j));
                    pointSizeF = size(freqPoints,1);
                    tSum = 0;

                    for i = 1:pointSizeF
                    tVal = tvalSub{s}(sigCluster{x}(freqPoints(i),1),sigCluster{x}(freqPoints(i),2));
                    tSum = tSum+tVal;
                    end   

                    tFSums(j) = tSum;
                end

                stem(freq(freqs),tFSums);
                hold on
                plot(freq(freqs),tFSums);
                xlabel('Frequency (Hz)');
                ylabel('Summed t-values');
            
            T = sprintf('Subject %g, Cluster #%g, Cluster t-value: %g',s,sigCluster{x}(1,3),tvalSums(sigCluster{x}(1,3)));
            suptitle(T);
              
                %Saving Cluster Image - Enter preferred directory for storing
                %figures of significant clusters

                fileName2 = sprintf('Subject %g, Cluster #%g, %s',s,sigCluster{x}(1,3),sign);
                %cd('/Users/eugenejoseph/Desktop/Matlab Data Archive/Mar-19-12/Sig.Cluster Images')
                saveas(clustVis,fullfile(fpath,'Sig.Cluster Images',fileName2),'fig') 
                close (clustVis);           
            
        end

    end
end

%Saving Data - Enter preferred directory for story data
%cd('/Users/eugenejoseph/Desktop/Matlab Data Archive/Mar-19-12')
fname = fullfile(fpath,['clusterStats' sign '.mat']);
save(fname,'tvalSumsSub','clustPointsCSub','tvalMonteSub','sigClusterSub','tvalSub','clustSizeSub');


